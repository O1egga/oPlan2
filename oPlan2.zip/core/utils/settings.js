// Настройки диаграммы

export function configureDiagram(diagram) {
  diagram.grid = new go.Panel("Grid").add(
    new go.Shape("LineH", {
      stroke: "#e6e6e6", //303030
      strokeWidth: 1,
    }),
    new go.Shape("LineV", {
      stroke: "#e6e6e6",
      strokeWidth: 1,
    }),
  )

  diagram.grid.visible = true
}

// Узлы
export const Nodes = {
  default: { category: "Other", fill: "#C0C0C0" }, // Silver
  rrl: { category: "RRL", fill: "#BDB76B" }, // DarkKhaki
  wifi: { category: "Wifi", fill: "#1E90FF" }, // DodgerBlue
  bts: { category: "BTS", fill: "#008B8B" }, // DarkCyan
  router: { category: "Router", fill: "#CD5C5C" }, // IndianRed
  mux: { category: "MUX", fill: "#BC8F8F" }, // RosyBrown
  vsat: { category: "VSAT", fill: "#4682B4" }, // SteelBlue
  ats: { category: "ATS", fill: "#CD853F" }, // Peru
  dslam: { category: "DSLAM", fill: "#8FBC8F" }, // DarkSeaGreen
  msan: { category: "MSAN", fill: "#5F9EA0" }, // CadetBlue
  frame: { category: "Frame", fill: "#F5DEB3" }, // Wheat
  board: { category: "Board", fill: "#F0E68C" }, // Khaki
  cross: { category: "Cross", fill: "#6495ED" }, // CornflowerBlue},
  pc: { category: "PC", fill: "#00BFFF" }, // DeepSkyBlue },
}

// Связи
const SOLID = []
export const Links = {
  default: { category: "", color: "black", width: 1, dash: SOLID },
  radio: { category: "radio", color: "#43A047", width: 9, dash: [2, 1] },
  eth: { category: "eth", color: "#757575", width: 3, dash: SOLID },
  e1: { category: "e1", color: "#BDBDBD", width: 3, dash: SOLID },
  opt: { category: "opt", color: "#FB8C00", width: 3, dash: SOLID },
  dif: { category: "dif", color: "#9E9E9E", width: 3, dash: SOLID },
}

// Группы
export const Groups = {
  country: { category: "gCountry", figure: "Rectangle", header: "#2F5D9F", fill: "#EEF4FC" },
  region: { category: "gRegion", figure: "Rectangle", header: "#4F81BD", fill: "#F2F7FD" },
  district: { category: "gDistrict", figure: "Rectangle", header: "#4FA3A5", fill: "#EEF9F8" },
  area: { category: "gArea", figure: "Rectangle", header: "#5FAF8F", fill: "#F0FAF4" },
  town: { category: "gTown", figure: "Rectangle", header: "#6AA84F", fill: "#F3FAEF" },
  building: { category: "gBuilding", figure: "Rectangle", header: "#9BBB59", fill: "#F7FAEE" },
  room: { category: "gRoom", figure: "Rectangle", header: "#D79B42", fill: "#FEF8EB" },
  rack: { category: "gRack", figure: "Rectangle", header: "#A66A3F", fill: "#FBF3EE" },
  frame: { category: "gFrame", figure: "Rectangle", header: "#8C5E58", fill: "#F7F0EF" },
  net: { category: "gNet", figure: "Trapezoid1", header: "#7B68A8", fill: "#F4F2FA" },
}
