const PORT_STYLE = {

  1: {
    title: "Optical",
    figure: "Triangle",
    width: 18,
    height: 18,
    fill: "#ff9800",
    stroke: "#404040",
    strokeWidth: 1,
    font: "bold 7pt sans-serif",
    textColor: "#000000"
  },

  2: {
    title: "Radio",
    figure: "Circle",
    width: 18,
    height: 18,
    fill: "#4fc3f7",
    stroke: "#404040",
    strokeWidth: 1,
    font: "bold 7pt sans-serif",
    textColor: "#000000"
  },

  3: {
    title: "Ethernet",
    figure: "Rectangle",
    width: 18,
    height: 18,
    fill: "#d9d9d9",
    stroke: "#404040",
    strokeWidth: 1,
    font: "bold 7pt sans-serif",
    textColor: "#000000"
  },

  4: {
    title: "Cross",
    figure: "Diamond",
    width: 18,
    height: 18,
    fill: "#81c784",
    stroke: "#404040",
    strokeWidth: 1,
    font: "bold 7pt sans-serif",
    textColor: "#000000"
  },

  5: {
    title: "Other",
    figure: "RoundedRectangle",
    width: 18,
    height: 18,
    fill: "#ffffff",
    stroke: "#404040",
    strokeWidth: 1,
    font: "bold 7pt sans-serif",
    textColor: "#000000"
  }

};

export function getPortStyle(type) {
  return PORT_STYLE[type] ?? PORT_STYLE[5];
}