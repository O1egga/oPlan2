import { applyPortStyle } from "./applyPortStyle.js"

export function applyNodePresentation(node) {

  if (!node.slots)
    return

  node.slots.forEach(slot => {

    slot.ports.forEach(port => {

      applyPortStyle(port)

    })

  })

}