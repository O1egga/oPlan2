import { createPort } from "./createPort.js"

export function createPortArea() {

  return new go.Panel("Vertical", { itemTemplate: createPort() })
    .bind("itemArray", "ports")

}