import { getPortStyle } from "../../core/styles/portStyle.js"

export function createPort() {

  return new go.Panel("Spot", {

    cursor: "pointer",

    portId: "",

    fromLinkable: true,
    toLinkable: true,

    margin: 1

  })

    .bind("portId", "id")
    .bind("width", "portTypeId", type => { return getPortStyle(type).width })
    .bind("height", "portTypeId", type => { return getPortStyle(type).height })

    .add(

      new go.Shape()

        .bind("figure", "portTypeId", type => { return getPortStyle(type).figure })
        .bind("fill", "portTypeId", type => { return getPortStyle(type).fill })
        .bind("stroke", "portTypeId", type => { return getPortStyle(type).stroke })
        .bind("strokeWidth", "portTypeId", type => { return getPortStyle(type).strokeWidth }),

      new go.TextBlock({
        editable: false,
        isMultiline: false
      })

        .bind("text", "name")
        .bind("font", "portTypeId", type => { return getPortStyle(type).font })
        .bind("stroke", "portTypeId", type => { return getPortStyle(type).textColor })

    )

}