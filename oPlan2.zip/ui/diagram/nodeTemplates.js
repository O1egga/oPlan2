// все шаблоны узлов
import { Nodes } from "../../core/utils/settings.js"
import { createNode } from "./createNode.js"

export function registerNodeTemplates(myDiagram) {

  Object.values(Nodes).forEach(node => {

    myDiagram.nodeTemplateMap.add(
      node.category,
      createNode(node.category, node.fill)
    );

  });

}