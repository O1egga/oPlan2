// все шаблоны групп

import { Groups } from "../../core/utils/settings"

export function registerGroupTemplates(myDiagram) {
  Object.values(Groups).forEach((group) => {
    addGroupTemplate(myDiagram, group.category, group.figure, group.fill, group.header)
  })
}

// функция добавления шаблона группы
function addGroupTemplate(myDiagram, category, figure, color, headerColor) {
  myDiagram.groupTemplateMap.add(
    category,
    new go.Group("Auto", {
      layout: new go.LayeredDigraphLayout({
        isRealtime: false,
      }),
    }).add(
      new go.Shape(figure, {
        fill: color,
        stroke: headerColor,
        strokeWidth: 2,
      }),
      new go.Panel("Table")
        .addRowDefinition(0, {
          background: headerColor,
        })
        .add(
          go.GraphObject.build("SubGraphExpanderButton", { margin: 4 }),
          new go.TextBlock({
            column: 1,
            stroke: "white",
            textAlign: "center",
            margin: 8,
          }).bind("text"),
          new go.Placeholder({
            row: 1,
            columnSpan: 2,
            padding: 12,
          }),
        ),
    ),
  )
}
