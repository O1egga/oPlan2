// все шаблоны связей
import { Links } from "../../core/utils/settings"

export function registerLinkTemplates(myDiagram) {
  Object.values(Links).forEach((link) => {
    addLinkTemplate(myDiagram, link.category, link.color, link.width, link.dash)
  })
}

// функция добавления шаблона линка
function addLinkTemplate(myDiagram, category, color, width, dash) {
  const line = new go.Shape({
    stroke: color,
    strokeWidth: width,
  })

  if (dash.length > 0) {
    line.strokeDashArray = dash
  }

  const template = new go.Link()

  template.add(line)

  myDiagram.linkTemplateMap.add(category, template)
}
